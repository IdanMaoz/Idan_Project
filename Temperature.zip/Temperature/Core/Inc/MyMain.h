/*
 * MyMain.h
 *
 *  Created on: Nov 17, 2022
 *      Author: student
 */

#ifdef __cplusplus


extern "C"{
#endif
	void myMain();
#ifdef __cplusplus
}
#endif
